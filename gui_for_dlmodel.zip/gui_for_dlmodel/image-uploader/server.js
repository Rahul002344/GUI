const express = require('express');
const multer = require('multer');
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');
const archiver = require('archiver');
const bodyParser = require('body-parser');
const app = express();
const { exec } = require('child_process');
// Add body-parser middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
const port = 8000;

// Set up a new storage engine for Multer to save the uploaded file
const newStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'Video');
  },
  filename: function (req, file, cb) {
    // Set the filename to "input_video.mp4"
    const filename = 'input_video.mp4';
    cb(null, filename);
  },
});

// Initialize Multer with the new storage engine
const newUpload = multer({ storage: newStorage });

// Serve static files from the "image-uploader" directory
app.use('/image-uploader', express.static('image-uploader'));

// Serve the Frames directory for download
app.get('/downloadImages', (req, res) => {
  const framesDirectory = 'Frames';

  // Create a zip archive of the Frames directory
  const archive = archiver('zip', {
    zlib: { level: 9 }, // Set compression level (optional)
  });

  // Set the response headers to indicate a zip file download
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename=frames.zip`);

  // Pipe the archive to the response stream
  archive.pipe(res);

  // Append all files in the Frames directory to the archive
  archive.directory(framesDirectory, false);

  // Finalize the archive
  archive.finalize();
});
// Handle POST requests to /upload
app.post('/upload/video', newUpload.single('video'), (req, res) => {
  // Check if a file was uploaded
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded.' });
  }

  // Assign videoFilePath within this route handler
  const videoFilePath = 'Video/' + req.file.filename;

  // Run the Python script after the file is uploaded
  const pythonScriptPath = 'vid_frames.py'; // Replace with the actual path to your Python script

  // Execute the Python script with the video file path as an argument
  exec(`python ${pythonScriptPath} ${videoFilePath}`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error executing Python script: ${error}`);
      // Send an error response
      return res.status(500).json({ message: 'Error creating frames.' });
    }

    console.log(`Python script output: ${stdout}`);
    
    // Send a success response indicating frames have been created successfully
    return res.status(200).json({ message: 'Frames have been created successfully' });
    
  
  });
});

const imageStorage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    cb(null, file.originalname); // Save the file with the original name
  },
});

const uploadImages = multer({
  storage: imageStorage,
  //limits: { fileSize: 200 * 1024 * 1024 }, // Limit total upload size to 200MB
}).array('image');

const classesStorage = multer.diskStorage({
  destination: 'Classes/',
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});
// Create Uploaded folder at server start
const uploadedFolderDir = path.join(__dirname, 'Uploaded folder');
if (!fs.existsSync(uploadedFolderDir)) {
  fs.mkdirSync(uploadedFolderDir);
}
const uploadClasses = multer({
  storage: classesStorage,
  //limits: { fileSize: 200 * 1024 * 1024 }, // Limit total upload size to 200MB
}).single('classes');

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Handle file upload
app.post('/upload', (req, res, next) => {
  uploadImages(req, res, function (err) {
    if (err instanceof multer.MulterError) {
      // Handle upload errors
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).send(`
          <h1>File upload size exceeds the limit (200MB).</h1>
          <button onclick="window.location.href='/'">Go back</button>
        `);
      }
      // Handle other multer errors
      return res.status(500).send(`
        <h1>An error occurred while uploading files.</h1>
        <pre>${err.message}</pre>
        <button onclick="window.location.href='/'">Go back</button>
      `);
    } else if (err) {
      // Handle other errors
      return res.status(500).send(`
        <h1>An error occurred while uploading files.</h1>
        <pre>${err.message}</pre>
        <button onclick="window.location.href='/'">Go back</button>
      `);
    }
    // Files uploaded successfully
    console.log(req.files);
    console.log('Files uploaded successfully');
    res.send(`
      <h1>Files uploaded successfully.</h1>
      <button onclick="window.location.href='/'">Go back</button>
    `);
  });
});

// // Handle file upload
// app.post('/upload-classes', uploadClasses, (req, res) => {
//   if (!req.file) {
//     return res.status(400).send('No file uploaded');
//   }

//   const uploadedFile = req.file;
//   console.log('File uploaded:', uploadedFile.filename);
//   res.send(`
//     <h1>File uploaded successfully.</h1>
//     <p>Filename: ${uploadedFile.filename}</p>
//     <button onclick="window.location.href='/'">Go back</button>
//   `);
// });
// POST endpoint for uploading classes.txt file
app.post('/upload-classes', uploadClasses, (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded');
  }

  const uploadedFile = req.file;
  console.log('File uploaded:', uploadedFile.filename);

  // Update classes.txt
  const uploadedFilePath = path.join(__dirname, 'Classes', uploadedFile.filename);
  const predefinedFilePath = path.join(__dirname, 'public', 'labelImg', 'data', 'predefined_classes.txt');

  // Read the uploaded classes file
  fs.readFile(uploadedFilePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading uploaded classes file:', err);
      return res.status(500).send('Error reading uploaded classes file');
    }

    // Write the uploaded classes to predefined_classes.txt
    fs.writeFile(predefinedFilePath, data, 'utf8', (writeErr) => {
      if (writeErr) {
        console.error('Error updating predefined classes file:', writeErr);
        return res.status(500).send('Error updating predefined classes file');
      }

      // Respond with success
      res.send(`
        <h1>File uploaded successfully.</h1>
        <p>Filename: ${uploadedFile.filename}</p>
        <button onclick="window.location.href='/'">Go back</button>
      `);
    });
  });
});

// Execute labelImg.py script and return to home page
app.get('/labelImg', (req, res) => {
  execFile('python', ['public/labelImg/labelImg.py'], (error, stdout, stderr) => {
    if (error || stderr) {
      console.error('Error:', error ? error.message : stderr);
      res.status(500).json({ error: 'An error occurred' });
      return;
    }
    console.log('LabelImg closed', stdout);
    // Send JavaScript code to navigate back to the main page
    res.send(`
      <script>
        window.history.back();
      </script>
    `);
  });
});

// Function to find the latest experiment directory
const findLatestExperimentDirectory = (directoryPath) => {
  const expDirs = fs
    .readdirSync(directoryPath)
    .filter((name) => fs.lstatSync(path.join(directoryPath, name)).isDirectory() && name.startsWith('exp'));

  // Sort the experiment directories based on their last modified timestamp
  expDirs.sort((a, b) => {
    const pathA = path.join(directoryPath, a);
    const pathB = path.join(directoryPath, b);
    return fs.lstatSync(pathB).mtimeMs - fs.lstatSync(pathA).mtimeMs;
  });

  return expDirs.length > 0 ? expDirs[0] : null; // Return the latest experiment directory or null if none found
};

// Function to create a ZIP archive of the labels and uploaded images
const createLabelsArchive = (expDir, res) => {
  const labelsPath = path.join('public', 'yolov5', 'runs', 'detect', expDir, 'labels'); // Path to the labels directory
  const archiveName = `labels_${expDir}.zip`; // Generate unique filename with experiment directory name
  const archivePath = path.join('public', archiveName); // Path to the ZIP archive

  const output = fs.createWriteStream(archivePath);
  const archive = archiver('zip', {
    zlib: { level: 9 }, // Set compression level (optional)
  });

  output.on('close', () => {
    console.log('Labels archive created:', archive.pointer() + ' total bytes');

    res.set('Content-Type', 'application/zip');
    res.set('Content-Disposition', `attachment; filename=${archiveName}`);
    fs.createReadStream(archivePath).pipe(res);
  });

  archive.on('error', (err) => {
    throw err;
  });

  archive.pipe(output);
  archive.directory(labelsPath, false); // Add the labels directory to the archive

  // Copy uploaded images to the labels directory
  const uploadPath = path.join(__dirname, 'uploads');
  const uploadedImages = fs.readdirSync(uploadPath);

  uploadedImages.forEach((image) => {
    const imagePath = path.join(uploadPath, image);
    const targetPath = path.join(labelsPath, image);

    fs.copyFileSync(imagePath, targetPath);
  });

  // Copy classes.txt to the labels directory
  const classesFilePath = path.join(__dirname, 'Classes', 'classes.txt');
  const targetClassesPath = path.join(labelsPath,'classes.txt');
  fs.copyFileSync(classesFilePath, targetClassesPath);

  archive.finalize();
};

app.get('/run-command', (req, res) => {
  execFile(
    'python',
    ['public/yolov5/detect.py', '--source', 'uploads/', '--weights', 'public/yolov5/besttt.pt', '--save-txt','--classes', '0', '1', '2', '3', '4', '5', '6', '7','8', '9', '10','12','14', '15','16','17','18','20','21', '22'],
    (error, stdout, stderr) => {
      if (error) {
        console.error('Error:', error.message);
        res.status(500).send(`
          <h1>An error occurred while executing the script.</h1>
          <pre>${error.message}</pre>
          <button onclick="window.location.href='/'">Go back</button>
        `);
        return;
      }
      if (stderr) {
        console.error('Error:', stderr);
        res.status(500).send(`
          <h1>An error occurred while executing the script.</h1>
          <pre>${stderr}</pre>
          <button onclick="window.location.href='/'">Go back</button>
        `);
        return;
      }
      console.log('Output:', stdout);
      // Find the latest experiment directory
      const expDir = findLatestExperimentDirectory('public/yolov5/runs/detect');

      createLabelsArchive(expDir, res); // Create the ZIP archive of labels
    }
  );
});
// POST endpoint for saving words to the classes.txt file

// POST endpoint for saving words to the classes.txt file
app.post('/save-words', (req, res) => {
  const words = req.body.words;

  if (!Array.isArray(words)) {
      return res.status(400).send('Invalid words data');
  }

  const filePath = path.join(__dirname, 'Classes', 'classes.txt');
  const formattedWords = words.join('\n') + '\n';

  fs.appendFile(filePath, formattedWords, (err) => {
      if (err) {
          console.error('Error saving words:', err);
          return res.status(500).send('Error saving words');
      }
      return res.status(200).send('Words saved successfully');
  });
});
app.get('/download-labels', (req, res) => {
  const detectOutputDir = path.join(__dirname, 'public', 'yolov5', 'runs', 'detect');
  const expDir = findLatestExperimentDirectory('public/yolov5/runs/detect');
  const expPath = path.join(detectOutputDir, expDir);

  // Check if 'exp' directory contains 'input_video.mp4'
  if (fs.existsSync(path.join(expPath, 'input_video.mp4'))) {
    // Zip the 'exp' directory and initiate download
    createExpArchive(expPath, res);
  } else {
    // Continue with existing code for labels
    createLabelsArchive(expDir, res); // Create the ZIP archive of labels
  }
});

// Define a function to create a ZIP archive of 'exp' directory
function createExpArchive(expPath, res) {
  // Create a writable stream for the response
  const output = res;
  const archive = archiver('zip', { zlib: { level: 9 } });

  // Set the archive name and type
  const archiveName = 'input_video.zip';

  // Set the response headers for downloading the ZIP archive
  res.setHeader('Content-Disposition', `attachment; filename="${archiveName}"`);
  res.setHeader('Content-Type', 'application/zip');

  // Pipe the archive to the response stream
  archive.pipe(output);

  // Add the entire 'exp' directory to the archive
  archive.directory(expPath, false);

  // Finalize the archive, and trigger the response to send the ZIP file
  archive.finalize();

  // Handle any errors that might occur during archiving
  archive.on('error', (err) => {
    console.error('Error while creating ZIP archive:', err);
    res.status(500).send('Error creating ZIP archive');
  });

  // When the archive is finished, close the response stream
  archive.on('end', () => {
    console.log('ZIP archive created successfully');
    output.end();
  });
}

app.get('/fetch-word-list', (req, res) => {
  const classesFilePath = path.join(__dirname, 'Classes', 'classes.txt');
  fs.readFile(classesFilePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading classes.txt:', err);
      return res.status(500).json({ error: 'An error occurred while fetching the word list' });
    }

    const words = data.split(',').map(word => word.trim());
    return res.status(200).json({ words: words });
  });
});

app.get('/fetch-word-list', (req, res) => {
  const classesFilePath = path.join(__dirname, 'Classes', 'classes.txt');
  fs.readFile(classesFilePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading classes.txt:', err);
      return res.status(500).json({ error: 'An error occurred while fetching the word list' });
    }

    const words = data.split(',').map(word => word.trim());
    return res.status(200).json({ words: words });
  });
});
// // POST endpoint for deleting a word from the classes.txt file
// app.post('/delete-word', (req, res) => {
//   const word = req.body.word;

//   if (!word) {
//     return res.status(400).send('Invalid word');
//   }

//   const filePath = path.join(__dirname, 'Classes', 'classes.txt');

//   fs.readFile(filePath, 'utf8', (err, data) => {
//     if (err) {
//       console.error('Error reading classes.txt:', err);
//       return res.status(500).send('An error occurred while deleting the word');
//     }

//     const words = data.split('\n').map(word => word.trim());
//     const filteredWords = words.filter(item => item !== word);

//     const updatedContent = filteredWords.join('\n');

//     fs.writeFile(filePath, updatedContent, 'utf8', (err) => {
//       if (err) {
//         console.error('Error deleting word:', err);
//         return res.status(500).send('An error occurred while deleting the word');
//       }

//       return res.status(200).send('Word deleted successfully');
//     });
//   });
// });

// HTML page with the "Labels" button

app.get('/', (req, res) => {
  res.send(`
    <h1>Image Uploader</h1>
    <form action="/upload" method="post" enctype="multipart/form-data">
      <input type="file" name="image" multiple>
      <input type="submit" value="Upload">
    </form>
    <button onclick="window.location.href='/labelImg'">Run labelImg.py</button>
    <button onclick="window.location.href='/download-labels'">Download Labels</button>
    <!-- Add the button for uploading classes.txt file -->
    <form action="/upload-classes" method="post" enctype="multipart/form-data">
      <input type="file" name="classes" accept=".txt">
      <input type="submit" value="Upload classes.txt">
    </form>
  `);
});

// Serve the static files
app.use(express.static('public')); // Make sure to place your HTML, CSS, and JS files in the "public" directory

// Fetch the list of classes from classes.txt
app.get('/fetch-classes-list', (req, res) => {
    fs.readFile('Classes/classes.txt', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'Failed to fetch classes list' });
        } else {
            const classes = data.split('\n').map(className => className.trim());
            res.json({ classes });
        }
    });
});

app.use(bodyParser.json());

// Serve your static files (HTML, CSS, JS, etc.)
app.use(express.static("public"));

app.post('/save-selected-class-numbers', (req, res) => {
  const classNumbers = req.body.classNumbers; // Get the class numbers from the request body

  // Remove duplicates using a Set
  const uniqueClassNumbers = new Set(classNumbers);

  // Convert the Set back to an array
  const uniqueClassNumbersArray = Array.from(uniqueClassNumbers);

  // Convert the array of class numbers to a string
  const classNumbersString = uniqueClassNumbersArray.join('\n');

  // Save the string to the selected_classes.txt file (overwrite mode)
  fs.writeFile('Classes/selected_classes.txt', classNumbersString, 'utf8', (err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error saving class numbers');
    } else {
      //console.log('Class numbers saved successfully');
      //res.send('Class numbers saved successfully');
    }
  });
});

// Endpoint to get the contents of output.txt
app.get('/get-terminal-output', (req, res) => {
    // Read the contents of the output.txt file
    fs.readFile('output.txt', 'utf8', (err, data) => {
        if (err) {
            res.status(500).json({ error: 'An error occurred while reading the output file.' });
        } else {
            res.json({ output: data });
        }
    });
});
// Configure Multer for handling file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
      cb(null, path.join(__dirname, 'Uploaded folder')); // Specify your upload destination
  },
  filename: function (req, file, cb) {
      cb(null, file.originalname);
  }
});
const upload = multer({ storage: storage });

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Endpoint for handling folder upload
app.post('/upload-folder', upload.array('folder'), (req, res) => {
  try {
      // Handle the uploaded folder here
      console.log('Folder uploaded:', req.files);
      res.status(200).send('Folder upload successful.');
  } catch (error) {
      console.error('Error during folder upload:', error);
      res.status(500).send('Folder upload failed.');
  }
});

app.use(express.static(path.join(__dirname, 'public')));

// Body parser middleware
app.use(bodyParser.json());

// Run Modify Classes route
app.get('/run-modify-classes', (req, res) => {
    exec('py -m modify_classes', (error, stdout, stderr) => {
        if (error) {
            console.error(`Error running Modify Classes: ${error}`);
            return res.status(500).json({ message: 'Error running Modify Classes', error: error.toString() });
        }

        console.log(`Modify Classes Output: ${stdout}`);
        return res.json({ message: 'Run Modify Classes successful', output: stdout });
    });
});

// Download Modified Folder route
app.get('/download-modified-folder', (req, res) => {
  const output = fs.createWriteStream('modified_folder.zip');
  const archive = archiver('zip', { zlib: { level: 9 } });

  output.on('close', () => {
    console.log(archive.pointer() + ' total bytes');
    console.log('archiver has been finalized and the output file has been closed.');
    res.download('modified_folder.zip'); // Send the zip file as a download
  });

  archive.on('error', (err) => {
    throw err;
  });

  archive.pipe(output);
  archive.directory('Uploaded folder', false); // Path to your Uploaded folder
  archive.finalize();
});
// Define the cleanup function to delete directories and files
const cleanup = () => {
  // Delete the contents of the Video directory
  const videoDir = path.join(__dirname,'Video');
  fs.readdirSync(videoDir).forEach((file) => {
    const filePath = path.join(videoDir, file);
    fs.unlinkSync(filePath);
  });

  // Delete the contents of the Frames directory
  const framesDir = path.join(__dirname, 'Frames');
  fs.readdirSync(framesDir).forEach((file) => {
    const filePath = path.join(framesDir, file);
    fs.unlinkSync(filePath);
  });

  // Delete the uploads directory
  const uploadsDir = path.join(__dirname, 'uploads');
  fs.rmdirSync(uploadsDir, { recursive: true });

  // // Delete the classes.txt file from the Classes directory
  // const classesFilePath = path.join(__dirname, 'Classes', 'classes.txt');
  // fs.unlinkSync(classesFilePath);
  const selectedClassesFilePath = path.join(__dirname, 'Classes', 'selected_classes.txt');
  fs.unlinkSync(selectedClassesFilePath);

  // Delete the experiment directories in runs/detect

  const detectOutputDir = path.join(__dirname, 'public', 'yolov5', 'runs', 'detect');
fs.readdirSync(detectOutputDir).forEach((folder) => {
  const folderPath = path.join(detectOutputDir, folder);
  if (fs.lstatSync(folderPath).isDirectory()) {
    fs.rmdirSync(folderPath, { recursive: true });
  }
});

  // Delete the contents of the Uploaded folder
  const uploadedFolderDir = path.join(__dirname, 'Uploaded folder'); // Change to your folder path
  const uploadedFiles = fs.readdirSync(uploadedFolderDir);
  uploadedFiles.forEach((file) => {
    const filePath = path.join(uploadedFolderDir, file);
    fs.unlinkSync(filePath);
  });
};

app.use(bodyParser.json());

// Handle POST requests to /runVideo
app.post('/runVideo', (req, res) => {
  // Execute the Python command
  const command = 'python public/yolov5/detect.py --source Video/input_video.mp4 --weights public/yolov5/besttt.pt';

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error executing command: ${error.message}`);
      res.status(500).send('Error executing command');
      return;
    }

    console.log(`Command output: ${stdout}`);
    res.status(200).send('Video processing completed.');
  });
});

// Shutdown event listener to trigger the cleanup function
const server = app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

// Handle server shutdown gracefully
process.on('SIGINT', () => {
  console.log('Server is shutting down...');
  cleanup();
  server.close(() => {
    console.log('Server has shut down.');
    process.exit(0);
  });
});