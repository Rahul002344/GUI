# Define the path to the file containing the target class indices
selected_classes_file = r"Classes/selected_classes.txt"

# Read the target class indices from the file
with open(selected_classes_file, "r") as classes_file:
    target_class_indices = [int(index) for index in classes_file.read().split()]
# Path to the directory containing your YOLO txt files
txt_files_directory = r"Uploaded folder"

# Name of the classes file
classes_filename = "classes.txt"

# Iterate through each txt file in the directory
import os

for filename in os.listdir(txt_files_directory):
    if filename.endswith(".txt") and filename != classes_filename:
        with open(os.path.join(txt_files_directory, filename), "r+") as file:
            lines = file.readlines()
            file.seek(0)  # Move the cursor to the beginning of the file
            file.truncate()  # Clear the contents of the file
            for line in lines:
                parts = line.split()
                if len(parts) == 5:  # Ensure the line has the correct format
                    detected_class_index = int(parts[0])
                    if detected_class_index in target_class_indices:
                        file.write(line)

#print("Modified txt files to include only the specified classes.")