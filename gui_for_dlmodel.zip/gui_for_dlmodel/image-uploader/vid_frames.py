import cv2
import os

video_file = 'Video/input_video.mp4'  
cap = cv2.VideoCapture(video_file)
frame_rate = cap.get(cv2.CAP_PROP_FPS)
print(f"Frame rate: {frame_rate}")
if not cap.isOpened():
    print("Error: Could not open video file.")
    exit()

desired_fps = 20  # Set the desired frame rate
frame_rate = cap.get(cv2.CAP_PROP_FPS)

# Ensure that frame_interval is not zero to prevent ZeroDivisionError
if frame_rate > 0:
    frame_interval = int(round(frame_rate / desired_fps))
else:
    print("Error: Invalid frame rate in the video file.")
    exit()

output_directory = 'Frames'
os.makedirs(output_directory, exist_ok=True)
frame_count = 0
frame_number = 0

while True:
    ret, frame = cap.read()

    if not ret:
        break

    if frame_number % frame_interval == 0:
        frame_filename = os.path.join(output_directory, f"{frame_count}.jpg")  
        cv2.imwrite(frame_filename, frame)
        frame_count += 1

    frame_number += 1

cap.release()

print(f"Total frames extracted: {frame_count}")